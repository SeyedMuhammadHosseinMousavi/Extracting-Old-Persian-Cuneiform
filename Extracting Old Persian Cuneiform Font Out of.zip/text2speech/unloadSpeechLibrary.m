function unloadSpeechLibrary
% unloads the speech library
%
% Note: I observed that Matlab might crash!!!
%
%% Signature
% Author: W.Garn
% E-Mail: wgarn@yahoo.com
% Date: 2006/06/04 22:20:00 
% 
% Copyright 2006 W.Garn
%
unloadlibrary('wgText2Speech');