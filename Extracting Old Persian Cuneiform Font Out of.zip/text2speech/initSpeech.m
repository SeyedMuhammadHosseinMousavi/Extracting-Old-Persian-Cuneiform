function initSpeech
% loads the speech library (a privat function)
% 
%% Signature
% Author: W.Garn
% E-Mail: wgarn@yahoo.com
% Date: 2006/06/04 22:20:00 
% 
% Copyright 2006 W.Garn
%
loadlibrary('wgText2Speech','Speak.h');
