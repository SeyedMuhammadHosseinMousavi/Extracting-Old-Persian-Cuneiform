clc;clear;
I=imread('c:\o\n3.jpg');
% J = imcomplement(I);
% imshow(I), figure, imshow(J)
% but it is better to use fuzzy edge detection becuse ,might the back
% ground be  in any other colors like red or yellow
[ocrI, results] = evaluateOCRTraining(I);
size=size(results.WordConfidences);

for ii=1:size(1:end,1)
    i=i+1;
end
for i=1:ii
%    label_str{i} = ['Confidence: ' num2str(results.WordConfidences(i)  ,'%0.2f') '%'];
      label_str{i} = [ num2str(results.WordConfidences(i)  ,'%0.2f') '%'];

end

     Iocr         = insertObjectAnnotation(I, 'rectangle', ...
                           results.WordBoundingBoxes, ...
                            label_str,'Color',{'green'},'FontSize',18);
     figure; imshow(Iocr);
     title('Cuneiform Output WordConfidences');

          Iocr         = insertObjectAnnotation(I, 'rectangle', ...
                           results.WordBoundingBoxes, ...
                            results.Words,'Color',{'green'},'FontSize',22);
     figure; imshow(Iocr);
     title('Cuneiform Output Words');
     
     results.Words'
     
str=results.Text;
stringss=string(str);
stringss

oldText = string({'Q','r','R','t','T','y','p','s','S',' ','d','D','f','g','h','j','k','K','l','z','Z','x','c','v','b','n','N','m','M','V',';','E','a','i','u'});
newText = string({'du','ra','ru','ta','tu','ya','pa','sa','sha','  ','da','di','fa','ga','ha','ja','ka','ku','la','za','sa','xa','cha','va','ba','na','nu','ma','mu','vi',' , ','King','a','i','u'});
newStr = replace(stringss,oldText,newText)
str2 = replace(str,oldText,newText);
dlmwrite('English-Pronunciation.txt',str2)

oldText1 = string({'ah','KuRuS','ait','mZiSt','kar','Zatiy','daryvuS','xSayZiy','mna','aurmzda','upstam','blauv','hda','ViZibiS','bgibiS','uta','imam','dhyaum','aulmzda','paTuv','hca','hinaya','QuSiyara','druga','abiy','ma','ajMiya','ait','aim','yanm','jDiyaMiy','miy','ddaTuv','QuSiyala'  });
newText2 = string({'Was ','Cyrus  ','This ','the Most Great ','Army ','Says','Darius','King','to Me','Ahura Mazda','Helper','Does','with','All','Gods','and','this','Country','Ahura Mazda','Keep and Save','from','Enemy','Drought','Lie','to','not','Become','That','Mine','Forgiveness','Ask','to','Give','Drought'      });
newStr2 = replace(stringss,oldText1,newText2)
str22 = replace(str,oldText1,newText2);
dlmwrite('English-Translation.txt',str22)

% oldText22 = string({'Q','r','R','t','T','y','p','s','S',' ','d','D','f','g','h','j','k','K','l','z','Z','x','c','v','b','n','N','m','M','V','u','a','i','E',' ',';'});
% newText22 = string({' ?? ',' ?? ',' ?? ',' ??',' ??',' ??',' ??',' ??',' ??','  ',' ??',' ??',' ??',' ??',' ??',' ??',' ??',' ??',' ??',' ??',' ??',' ??',' ??',' ??',' ??',' ??','??',' ??',' ??',' ??',' ??',' ?',' ??',' ??????','  ',' ? '});
% newStr22 = replace(stringss,oldText22,newText22)
% str222 = replace(str,oldText22,newText22);

% oldText23 = string({'ah','KuRuS','ait','mZiSt','kar','Zatiy','daryvuS','xSayZiy','mna','aurmzda','upstam','blauv','hda','ViZibiS','bgibiS','uta','imam','dhyaum','aulmzda','paTuv','hca','hinaya','QuSiyara','druga','abiy','ma','ajMiya','ait','aim','yanm','jDiyaMiy','miy','ddaTuv','QuSiyala'  });
% newText23 = string({' ??? ',' ????? ',' ?? ',' ???? ???? ',' ???? ',' ???? ',' ?????? ',' ??? ',' ??? ',' ????????? ',' ????? ',' ??? ',' ?? ',' ??? ',' ?????? ',' ? ',' ??? ',' ?????? ',' ????? ???? ',' ????? ',' ?? ',' ???? ',' ??????? ',' ???? ',' ?? ??? ',' ?? ',' ??? ',' ??? ?? ',' ?? ',' ????? ',' ??????? ?? ??? ',' ??? ??? ',' ???? ',' ??????? '});
% newStr23 = replace(stringss,oldText23,newText23)
% str223 = replace(str,oldText23,newText23);
% dlmwrite('[Persian-Pronunciation.txt',str223)

newchar=char(newStr);
%       tts(newchar)
%    tts(str22)